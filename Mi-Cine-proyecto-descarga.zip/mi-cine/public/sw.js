const CACHE = 'mi-cine-shell-v3';
self.addEventListener('install', event => event.waitUntil((async()=>{
  const cache=await caches.open(CACHE);
  const response=await fetch('/');
  const html=await response.clone().text();
  await cache.put('/',response);
  await cache.put('/index.html',new Response(html,{headers:{'Content-Type':'text/html; charset=utf-8'}}));
  const assets=[...html.matchAll(/(?:src|href)="([^"]+\.(?:js|css))"/g)].map(match=>match[1]).filter(path=>path.startsWith('/'));
  await cache.addAll(['/manifest.webmanifest','/icons/icon.svg','/icons/icon-192.png','/icons/icon-512.png',...assets]);
})()));
self.addEventListener('activate', event => event.waitUntil((async()=>{const keys=await caches.keys();await Promise.all(keys.filter(k=>k.startsWith('mi-cine-')&&k!==CACHE&&k!=='mi-cine-images-v1').map(k=>caches.delete(k)));await self.clients.claim()})()));
self.addEventListener('fetch', event => {
  const req=event.request;if(req.method!=='GET')return;const url=new URL(req.url);
  if(url.origin===location.origin){event.respondWith((async()=>{const cache=await caches.open(CACHE);try{const fresh=await fetch(req);if(fresh.ok)await cache.put(req,fresh.clone());return fresh}catch{return (await cache.match(req))||(await cache.match('/'))}})())}
  else if(url.hostname==='image.tmdb.org'){event.respondWith((async()=>{const cache=await caches.open('mi-cine-images-v1');const cached=await cache.match(req);if(cached)return cached;try{const res=await fetch(req);if(res.ok)await cache.put(req,res.clone());return res}catch{return new Response('',{status:504})}})())}
});
