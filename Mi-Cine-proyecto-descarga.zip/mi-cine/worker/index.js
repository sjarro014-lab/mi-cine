const API = 'https://api.themoviedb.org/3';
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Max-Age': '86400'
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'public, max-age=300' }
  });
}

function dateString(date = new Date()) {
  return date.toISOString().slice(0, 10);
}

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { headers: CORS });
    if (request.method !== 'GET') return json({ error: 'Método no permitido.' }, 405);

    const url = new URL(request.url);
    const path = url.pathname;
    if (path === '/health') return json({ ok: true, service: 'Mi Cine catalog proxy' });
    if (!env.TMDB_ACCESS_TOKEN) return json({ error: 'Falta configurar TMDB_ACCESS_TOKEN en los secretos de Cloudflare.' }, 503);

    const headers = {
      Authorization: `Bearer ${env.TMDB_ACCESS_TOKEN}`,
      'Content-Type': 'application/json;charset=utf-8'
    };
    const requestTmdb = async endpoint => {
      const response = await fetch(API + endpoint, { headers });
      const data = await response.json();
      if (!response.ok) throw new Error(data.status_message || 'TMDB no pudo completar la consulta.');
      return data;
    };

    try {
      let data;
      if (path === '/search') {
        const query = url.searchParams.get('query')?.trim();
        if (!query) return json({ error: 'Falta el parámetro query.' }, 400);
        data = await requestTmdb(`/search/multi?query=${encodeURIComponent(query)}&include_adult=false&language=es-CO&page=1`);
      } else if (path === '/discover') {
        const category = url.searchParams.get('category') || 'trending';
        const today = dateString();
        const recent = dateString(new Date(Date.now() - 180 * 86400000));
        const endpoints = {
          trending: ['/trending/all/week?language=es-CO'],
          popular: ['/movie/popular?language=es-CO&region=CO', '/tv/popular?language=es-CO'],
          upcoming: [`/discover/movie?language=es-CO&include_adult=false&sort_by=primary_release_date.asc&primary_release_date.gte=${today}&region=CO`],
          now_playing: ['/movie/now_playing?language=es-CO&region=CO'],
          tv: [`/discover/tv?language=es-CO&sort_by=first_air_date.desc&first_air_date.gte=${recent}&first_air_date.lte=${today}`]
        };
        const selected = endpoints[category];
        if (!selected) return json({ error: 'Categoría de descubrimiento no válida.' }, 400);
        const responses = await Promise.all(selected.map(requestTmdb));
        const results = responses.flatMap((result, index) => (result.results || []).map(item => ({
          ...item,
          media_type: item.media_type || (selected.length > 1 ? (index === 0 ? 'movie' : 'tv') : (item.first_air_date ? 'tv' : 'movie'))
        })));
        data = { page: 1, results, total_results: results.length, total_pages: 1 };
      } else if (path.startsWith('/details/')) {
        const parts = path.split('/').filter(Boolean);
        const type = parts[1];
        const id = parts[2];
        if (!['movie', 'tv'].includes(type) || !/^\d+$/.test(id || '')) return json({ error: 'Título no válido.' }, 400);
        const raw = await requestTmdb(`/${type}/${id}?language=es-CO&append_to_response=release_dates,content_ratings`);
        const genres = (raw.genres || []).map(genre => genre.name).filter(Boolean);
        const countries = (raw.production_countries || raw.origin_country?.map(code => ({ name: code })) || [])
          .map(country => country.name || country.iso_3166_1).filter(Boolean);
        return json({
          ...raw,
          title: raw.title || raw.name,
          year: (raw.release_date || raw.first_air_date || '').slice(0, 4),
          type,
          genres,
          countries,
          runtime: type === 'movie' ? (raw.runtime || null) : null,
          posterPath: raw.poster_path || '',
          overview: raw.overview || '',
          tmdbId: raw.id
        });
      } else {
        return json({ error: 'Ruta no encontrada.' }, 404);
      }

      if (Array.isArray(data.results)) {
        data.results = data.results
          .filter(item => item.media_type !== 'person')
          .map(item => ({ ...item, media_type: item.media_type || (item.first_air_date ? 'tv' : 'movie') }));
      }
      return json(data);
    } catch (error) {
      return json({ error: error?.message || 'No fue posible conectar con TMDB.' }, 502);
    }
  }
};
