from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parents[1]
icons = root / 'public' / 'icons'
icons.mkdir(parents=True, exist_ok=True)
size = 512
im = Image.new('RGBA', (size, size), '#0b0b0c')
d = ImageDraw.Draw(im)
d.rounded_rectangle((42, 42, 470, 470), radius=104, fill='#171415', outline='#54232b', width=10)
d.rounded_rectangle((112, 118, 400, 360), radius=34, fill='#8f1d2c')
# Film perforations along both edges.
for x in (145, 205, 265, 325, 385):
    d.rounded_rectangle((x - 10, 104, x + 10, 136), radius=7, fill='#d98b94')
    d.rounded_rectangle((x - 10, 342, x + 10, 374), radius=7, fill='#d98b94')
# Play symbol.
d.polygon([(224, 184), (224, 294), (322, 239)], fill='#f4eeee')
try:
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 31)
except OSError:
    font = ImageFont.load_default()
label = 'MI CINE'
bbox = d.textbbox((0, 0), label, font=font)
d.text(((size - (bbox[2] - bbox[0])) / 2, 402), label, font=font, fill='#e8dfe0')
im.save(icons / 'icon-512.png', optimize=True)
im.resize((192, 192), Image.Resampling.LANCZOS).save(icons / 'icon-192.png', optimize=True)

res = root / 'android' / 'app' / 'src' / 'main' / 'res'
sizes = {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}
for density, px in sizes.items():
    folder = res / f'mipmap-{density}'
    folder.mkdir(parents=True, exist_ok=True)
    icon = im.resize((px, px), Image.Resampling.LANCZOS)
    icon.save(folder / 'ic_launcher.png', optimize=True)
    mask = Image.new('L', (px, px), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, px - 1, px - 1), fill=255)
    round_icon = icon.copy()
    round_icon.putalpha(mask)
    round_icon.save(folder / 'ic_launcher_round.png', optimize=True)
print('Mi Cine icons generated.')
