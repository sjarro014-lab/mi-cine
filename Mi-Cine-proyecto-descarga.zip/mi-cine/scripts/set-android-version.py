import os
import re
from pathlib import Path

build_file = Path('android/app/build.gradle')
if not build_file.exists():
    raise SystemExit('No se encontró android/app/build.gradle después de crear el proyecto Android.')
run_number = int(os.environ.get('GITHUB_RUN_NUMBER', '1'))
text = build_file.read_text()
text, code_count = re.subn(r'(?m)(versionCode\s+)\d+', rf'\g<1>{run_number}', text, count=1)
text, name_count = re.subn(r'(?m)(versionName\s+["\'])[^"\']*(["\'])', rf'\g<1>1.0.{run_number}\2', text, count=1)
if code_count != 1 or name_count != 1:
    raise SystemExit('No fue posible actualizar versionCode/versionName en Gradle.')
build_file.write_text(text)
print(f'Android version: 1.0.{run_number} (code {run_number})')
