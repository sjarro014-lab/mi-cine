# MI CINE — Aplicación Android

Mi Cine es una biblioteca cinematográfica personal para Android. La aplicación se entrega como APK instalable y mantiene la colección en el propio dispositivo.

## Funciones incluidas

- Biblioteca de películas y series, con búsqueda local, filtros y orden por añadidos recientemente.
- Estados: Pendiente, Viendo, Vista y Abandonada.
- Calificaciones personales de 0 a 5 con medias estrellas; cero es una calificación válida y distinta de «Sin calificar».
- Registro y edición de fecha de alta y fecha de visualización.
- Listas múltiples por título, listas personalizadas y categorías personales editables.
- Carpetas y sagas personalizadas con progreso automático.
- Mi Top: las películas se incorporan al marcarlas como vistas y se pueden reordenar.
- Estadísticas personales por tipo, tiempo estimado, géneros, países, meses y años.
- Pósteres de TMDB, imágenes propias, enlaces de imagen y portada genérica.
- Archivo y eliminación independiente.
- Copias de seguridad JSON con validación al restaurar.
- Base de datos local IndexedDB y caché offline.
- Catálogo online mediante un proxy privado de credenciales para TMDB.

## Compilar el APK desde GitHub usando solo el celular

No necesitas extraer carpetas ni tener computador. GitHub compilará el APK en sus servidores.

1. Descarga `Mi-Cine-proyecto.zip` y el archivo `Mi-Cine-GitHub-APK.yml` que acompaña al proyecto.
2. Crea un repositorio nuevo en https://github.com/new y déjalo **privado**. El proyecto incluye una clave de firma estable para que las futuras versiones puedan instalarse como actualizaciones conservando tus datos.
3. En el repositorio, usa **Add file → Upload files** y sube únicamente `Mi-Cine-proyecto.zip`.
4. Usa **Add file → Create new file**. En el nombre escribe exactamente `.github/workflows/android.yml`.
5. Abre `Mi-Cine-GitHub-APK.yml` en tu celular, copia todo su contenido y pégalo en el editor de GitHub. Guarda con **Commit changes**.
6. Abre **Actions → Build Mi Cine APK from uploaded ZIP → Run workflow**.
7. La primera ejecución extraerá el ZIP, guardará el proyecto completo en el repositorio y compilará el APK. Cuando termine en verde, abre la ejecución y descarga el artefacto **Mi-Cine-Android-APK**. GitHub lo entrega como ZIP; extrae `app-debug.apk` e instálalo en Android.

Después de esa primera ejecución, el repositorio ya tendrá los archivos completos y el workflow normal **Build Mi Cine APK**. Para futuras versiones podrás ejecutar ese workflow directamente.

El APK debug está firmado con la misma clave estable del proyecto y su número de versión aumenta en cada ejecución, para permitir instalar futuras actualizaciones conservando los datos locales. No publiques el archivo de firma ni conviertas el repositorio en público. Android puede pedir que autorices la instalación desde el navegador o gestor de archivos que uses.

## Conectar el catálogo TMDB sin computador

El Worker se despliega también desde GitHub Actions. Para ello:

1. Solicita tu API Read Access Token en https://www.themoviedb.org/settings/api.
2. En Cloudflare, crea un API Token con permiso **Workers Scripts: Edit** y copia el Account ID de tu cuenta.
3. En el repositorio GitHub abre **Settings → Secrets and variables → Actions → New repository secret** y crea estos tres secretos, respetando los nombres:
   - `CF_API_TOKEN`: token de Cloudflare.
   - `CF_ACCOUNT_ID`: Account ID de Cloudflare.
   - `TMDB_ACCESS_TOKEN`: API Read Access Token de TMDB.
4. Abre **Actions → Deploy Mi Cine catalog service → Run workflow**.
5. Al finalizar, copia la dirección `workers.dev` que muestra el despliegue. En Mi Cine entra a **Ajustes → Conexión con el catálogo**, pega esa dirección y pulsa **Probar conexión**.

No escribas el token de TMDB dentro de la aplicación ni lo publiques en el repositorio. El Worker lo recibe como secreto.

## Datos y funcionamiento sin conexión

La biblioteca, listas, carpetas, categorías, ranking y notas se guardan en IndexedDB del dispositivo. El catálogo requiere internet. Los archivos de la aplicación y los recursos consultados se almacenan en caché; las imágenes que ya se hayan cargado pueden seguir disponibles sin conexión. Exporta copias de seguridad antes de borrar los datos de la aplicación o cambiar de dispositivo.

## Atribución

Este producto utiliza la API de TMDB, pero no está respaldado ni certificado por TMDB. La atribución y las condiciones de uso de TMDB deben mantenerse visibles y respetarse.
